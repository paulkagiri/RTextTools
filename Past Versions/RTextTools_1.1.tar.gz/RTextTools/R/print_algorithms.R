print_algorithms <- function() {
	algorithms <- c("SVM","SLDA","BOOSTING","BAGGING","RF","GLMNET","TREE","NNET","MAXENT")
	print(algorithms)
}